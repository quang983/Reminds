package com.example.reminds.common

object Constants {
    const val BASE_URL = "https://wallhaven.cc/"
    const val TAG = "LOG_COMMON"
}


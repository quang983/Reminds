package com.example.data.local.database

import androidx.room.Dao
import androidx.room.Query

@Dao
interface BaseLocalDao<Result> {

}
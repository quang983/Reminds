package com.example.reminds

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class AppComponent : Application()
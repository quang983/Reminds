package com.example.reminds.ui.fragment.home

import net.citigo.kiotviet.pos.fnb.ui.viewmodels.BaseViewModel

class HomeViewModel : BaseViewModel() {

}
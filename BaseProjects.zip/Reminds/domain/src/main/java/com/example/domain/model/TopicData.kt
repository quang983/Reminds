package com.example.domain.model

data class TopicData(val id : Long,val title : String,val dateTime : Long)
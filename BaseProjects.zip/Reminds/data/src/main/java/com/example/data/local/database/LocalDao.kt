package com.example.data.local.database

interface LocalDao {
}